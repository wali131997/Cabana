import React, { Component } from "react";
import HeroSection from "../AboutUsPage/components/HeroSection";
import DepositeTable from "./components/DepositeTable";
import "./components/depositeWithdraw.css";
export default class DepositWithdrawPage extends Component {

  constructor(){
    super()
    this.state={active:true}
  }

  // handle change
  handleChangeFun(){
    this.setState({
      active:!this.state.active
    })
  }
  render() {
    const {active}=this.state
    return (
      <div>
        <HeroSection
          title="DEPOSIT/WITHDRAWAL"
          text="List of Deposit and Withdrawl Method by Cabana Capitals"
        />
<div className="pt-4 depositToggle">

  <div className="outerDiv" onClick={this.handleChangeFun.bind(this)}>
    <div className={active===true? "innerDivActive borderRight" :"innerDivActive innerDiv"}>Deposit</div>
    <div className={active===false? "innerDivActive borderLeft" :" innerDivActive innerDiv"}>Withdrawl</div>
  </div>
</div>
    <DepositeTable/>

    <div
    className="depositTrading">
      <div className="basicRow text-center w-100">

        <div className="title">Trading Platform</div>
        <div>
          <hr className="depositDivider" />
          <div className="depositeDividerOverlay"></div>
        </div>
        <img src="/assets/images/tradingPlatform2.png" alt="deposit trading" className="Img mt-5" ></img>
        <p className="text">Trade Currencies, Gold, Crude Oil, and more using MetaTrader4, the worlds most reliable Trading Platform<br/>
Trade the markets from Any Desktop, Android and IOS. Carry</p>
        <div className="">
          <button className="depositButton mr-0 mr-md-5 mb-3 mb-md-0">Open Live Account</button>
          <button className="depositButton">Open Demo Account</button>
        </div>
      </div>
      
    </div >

    <div className="container-fluid">
      <div className="row depositCardRow">
    <div className="col-12 text-center">  <div className="depositStepsTitle">Start Trading in 4 Steps</div>
    <div>
          <hr className="depositDivider" />
          <div className="depositeDividerOverlay"></div>
        </div>
    </div>
    <div className="col-lg-3 col-md-6 col-sm-12 mt-5 depositCard">
      <div className="outerDiv">
      <div className="centerDiv">  <img className="Img" src="/assets/images/deposite1.png" alt="card"></img></div>
        <h4 className="title">Register</h4>
        <p className="text">Open your live trading account via Cabana Capitals</p>
      </div>
    </div>
    <div className="col-lg-3 col-md-6 col-sm-12 mt-5 depositCard">
      <div className="outerDiv">
      <div className="centerDiv">  <img className="Img" src="/assets/images/deposite2.png" alt="card"></img></div>
        <h4 className="title">Verify</h4>
        <p className="text">
Upload your documents
to verify
your account</p>
      </div>
    </div>
    <div className="col-lg-3 col-md-6 col-sm-12 mt-5 depositCard">
      <div className="outerDiv">
      <div className="centerDiv">  <img className="Img" src="/assets/images/deposite3.png" alt="card"></img></div>
        <h4 className="title">fund</h4>
        <p className="text">Login to Cabana Capitals
and fund
your account</p>
      </div>
    </div>
    <div className="col-lg-3 col-md-6 col-sm-12 mt-5 depositCard">
      <div className="outerDiv">
      <div className="centerDiv">  <img className="Img" src="/assets/images/deposite4.png" alt="card"></img></div>
        <h4 className="title">Trade</h4>
        <p className="text">Start trading on
more than
250 instruments</p>
      </div>
    </div>

    <div className="col-12 text-center mt-5 mb-5">
    <button className="depositButton " style={{padding:"8px 70px"}} >Get Started</button>
    </div>
      </div>
    </div>

      </div>
    );
  }
}
