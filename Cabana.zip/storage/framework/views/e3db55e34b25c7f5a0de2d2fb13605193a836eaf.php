<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- Canonical Tags -->

<link rel="canonical" href="https://www.cabanacapitals.com/" />
<!-- frontend_index_index -->
<title>True ECN Forex broker, Online Forex Trading, CFD Trading - Cabana Capitals</title>
<meta name="description" content="Trade with True ECN Forex Broker and best trading conditions: Low Spreads, No Swaps, No Commissions."/>
<meta name="keywords" content="cabana capitals, true ecn forex broker, forex, forex trading, broker, currency trading, deposit, bonus, forex broker, no requote, no deposit bonus, deposit bonus, visa, mastercard, octafx, fbs, tickmill, superforex, liteforex, icmarkets, weltrade, iforex, best forex broker, nord forex "/>
<!-- Open Graph Data -->
<meta property="og:url" content="https://www.cabanacapitals.com/"/>
<meta property="og:title" content="True ECN Forex broker, Online Forex Trading, CFD Trading - Cabana Capitals"/>
<meta property="og:description" content="Trade with True ECN Forex Broker and best trading conditions: Low Spreads, No Swaps, No Commissions."/>
<meta property="og:type" content="website"/>

<meta property="og:site_name" content="Cabana Capitals">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="thumbnail" content="/assets/images/logo.png" />
<link rel="shortcut icon" href="/assets/images/favicon.ico">
  <title>Cabana Capitals | Forex Trading with True ECN Forex Broker</title>
  <!-- Font Awesome -->
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet"type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet"type="text/css" href="<?php echo e(asset('css/animate.css')); ?>">
        <link rel="stylesheet" href=" https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link
      rel="stylesheet"
      type="text/css"
      href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css"
    /><script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/plugins/debug.addIndicators.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.7/ScrollMagic.min.js"></script>

        <!-- Styles -->

    </head>
    <body>
        <div id="root">
        </div>
        <!-- <script src="js/jquery.min.js" type="text/javascript"></script> -->
<!-- <script src="js/jquery.dataTables.min.js" type="text/javascript"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <script
      type="text/javascript"
      charset="utf8"
      src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"
    ></script>
        <script type="text/javascript" src ="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Users\Z50-A\Documents\projects\cabanacapitals\Cabana\resources\views/welcome.blade.php ENDPATH**/ ?>