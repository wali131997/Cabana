import React, { Component } from "react";

export default class GetStartedSec extends Component {
  render() {
    return (
      <div className="text-center mb-4">
        <button className="btnPrimaryPink2 pl-3 pr-3 mt-2">GET STARTED</button>
      </div>
    );
  }
}
