import React, { Component } from 'react';

class TradingPlatformNew extends Component {
    render() {
        return (
            <div className="tradingNewBg">
                
                    <div className=" tradingNew">
                        
                            <div className="title">TRADING PLATFORMS</div>
                            <div className="text">Trade currencies, Gold, Curd Oil, and more using<br/> MetaTrader4, the world most reliable trading platform<br/>
Trade the market from any Desktop, Andriod, IOS, Carry<br/> your office with you.</div>

<div className="d-flex"><button className="btn1">Open Live Account</button><button className="btn2">Open Demo Account</button></div>
                      
                    </div>
           
            </div>
        );
    }
}

export default TradingPlatformNew;