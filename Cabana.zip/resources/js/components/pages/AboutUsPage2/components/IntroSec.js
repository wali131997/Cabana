import React, { Component } from 'react';

class IntroSec extends Component {
    render() {
        return (
            <div className="aboutUs2Bg">
               <div className="introSecBg1">

                   <div className="title">
                   Cabana Capitals -True ECN <br/>Forex Broker
                   </div>
                   </div>
               <div className="introSecBg2">

                   <div className="title">
                   WHY CABANA CAPITALS?
                   </div>
                   <div className="text">At Cabana Capitals, we constantly strive to customize our products and services to make sure that we have something for every market. We are always looking for opportunities to grow and develop as an organization that respects and appreciates its employees, clients and business partners. That is why we understand the value of your time and promise to waste not even a second of it. Your time is the first investment you make with us, and we can guarantee that we will keep your interest long enough to see fruitful affiliations. Trust Cabana Capitals to guide you through each and every step of your trading process like so many traders have done worldwide.</div>
                   </div>

            </div>
        );
    }
}

export default IntroSec;
