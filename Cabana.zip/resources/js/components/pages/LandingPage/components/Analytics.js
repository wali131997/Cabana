import React, { Component } from "react";

export default class Analytics extends Component {
 constructor(props) {
   super(props);
   this.state = {
    date: new Date(),
    analyticData: [
      {
        time: "2:30",
        currency: "NZD",
        event: "BuisnessNZ Services Index",
        eventColor: "yellow",
        actualColor: "green",
        actual: "8.63%",
        forcast: "8.63%",
        previous: "2.9%",
      },
      {
        time: "4:50",
        currency: "JPY",
        event: "Adjusted Trade Balance",
        eventColor: "green",
        actualColor: "green",
        actual: "12.51%",
        forcast: "12.51%",
        previous: "8.18%",
      },
      {
        time: "4:50",
        currency: "JPY",
        event: "Trade Balance",
        eventColor: "grey",
        actualColor: "red",
        actual: "-2.14%",
        forcast: "-2.14%",
        previous: "-0.79%",
      },
    ],
  };
 }
 
  render() {
    return (
      <div>
        <div className="analyticBox">
          <div className="container-fluid">
            <div className="row  ">
              <div className="col-12">
                <h2 className="titleFont text-center">ANALYTICS</h2>
                <p className="textFont mh10vw ph5vw">
                  After bottoming out in 119.80 or yearly lows, the cross
                  manageed to retake the key barrier at 120.00 the figure and is
                  now looking to consolidate around those levels. the daily
                  recovery in the European currency stays underpinned by the
                  dovish message conis.
                </p>
              </div>
            </div>
            <div className="mainAnalyticBox">
              <div className="col-md-12 col-sm-12 mb-4">
                <div className="analyticButtonRow">
                  <div className="">
                    <button className="btnPrimaryPink2">
                      ECONOMIC CALENDER
                    </button>
                  </div>
                  <div className="">
                    <button className="btnPrimaryOutline">
                      TECHNICAL ANALYSIS
                    </button>
                  </div>
                  <div className="">
                    <button className="btnPrimaryOutline">COMPANY NEWS</button>
                  </div>
                </div>
              </div>
              <div className=" dateTimeRow">
                <div className="calenderBox d-inline">
                  <img
                    className="calenderImage d-inline"
                    src="/assets/images/calenderIcon.png"
                  ></img>
                  <p className="textFont bold d-inline pl-1">19-25 Oct, 2020</p>
                </div>
                <div className="timeBox">
                  <p className="textFont bold">Current time : 0:39 (GMT)</p>
                </div>
              </div>
              <div className="tableOuterBox">
                <div className="tableHeader">
                  <div className="textFont textBold headerTime">Time</div>
                  <div className="textFont textBold headerCurrency">
                    Currency
                  </div>
                  <div className="textFont textBold headerEvent">Event</div>
                  <div className="textFont textBold headerActual">
                    <span className=" d-none  d-md-block">Actual</span>
                    <span className=" d-sm-block d-md-none">Act</span>
                  </div>
                  <div className="textFont textBold headerForcast">
                    <span className=" d-none  d-md-block">Forcast</span>
                    <span className=" d-sm-block d-md-none">Fcst</span>
                  </div>
                  <div className="textFont textBold headerPrevious">
                    <span className=" d-none  d-md-block">Previous</span>
                    <span className=" d-sm-block d-md-none">Pre</span>
                  </div>
                </div>
                <div className="tableContentBox">
                  {this.state.analyticData &&
                    this.state.analyticData.map((data) => {
                      return (
                        <div className="contentRow">
                          <div className="contentText headerTime">
                            {data.time}
                          </div>
                          <div className="contentText headerCurrency">
                            {data.currency}
                          </div>
                          <div className=" headerEvent">
                            <div className=" d-flex">
                              <div
                                className="eventColorBox mr-3 "
                                style={{ backgroundColor: data.eventColor }}
                              ></div>
                              <div className="contentText">{data.event}</div>
                            </div>
                          </div>
                          <div
                            className="contentText headerActual"
                            style={{ color: data.actualColor }}
                          >
                            {data.actual}
                          </div>
                          <div
                            className="contentText headerForcast"
                            style={{ color: data.actualColor }}
                          >
                            {data.forcast}
                          </div>
                          <div
                            className="contentText headerPrevious"
                            style={{ color: data.actualColor }}
                          >
                            {data.forcast}
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
