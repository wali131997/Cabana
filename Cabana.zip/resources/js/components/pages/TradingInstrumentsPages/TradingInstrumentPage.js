import React, { Component } from "react";
import HeroSec2 from "./components/HeroSec2";
import { Link } from "react-router-dom";
import "./components/tradingInstruments.css";
import TradingInstrumentComponent from "./components/TradingInstrumentComponent";
export default class TradingInstrumentPage extends Component {
  render() {
    return (
      <div>
        <HeroSec2
          title="TRADE THE WORLD'S MARKETS"
          text="We offer to a wide range of asset classes, including"
          text2="FX , precious metals and indices."
        />
        <TradingInstrumentComponent />
      </div>
    );
  }
}
